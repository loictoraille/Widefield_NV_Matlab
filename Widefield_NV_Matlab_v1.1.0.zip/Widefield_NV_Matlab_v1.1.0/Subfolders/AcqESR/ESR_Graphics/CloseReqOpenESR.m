
function CloseReqOpenESR(~,~)

panel=guidata(gcbo);

% available for stuff if needed

delete(gcf)

end