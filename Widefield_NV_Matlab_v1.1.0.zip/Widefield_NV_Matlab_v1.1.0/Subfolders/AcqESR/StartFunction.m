function StartFunction(i_scan)
global M ObjCamera CameraType handleImage smb TestWithoutHardware RF_Address Lum_Current

StartScript; 

ScanScript;

end