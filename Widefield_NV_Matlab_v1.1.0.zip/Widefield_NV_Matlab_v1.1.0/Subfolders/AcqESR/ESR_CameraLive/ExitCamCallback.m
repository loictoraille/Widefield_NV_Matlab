
function ExitCamCallback(~,~)
global ObjCamera CameraType

Exit_Camera()

end