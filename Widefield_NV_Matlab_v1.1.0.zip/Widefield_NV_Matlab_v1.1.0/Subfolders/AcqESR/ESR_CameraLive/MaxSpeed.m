function MaxSpeed(object,eventdata)

OptimizeAcquisitionSpeed();
UpdateCameraRanges();

end