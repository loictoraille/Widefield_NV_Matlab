function Input_Pixels(~,~)
global M

FuncInputPixels();

end
