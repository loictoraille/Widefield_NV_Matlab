function UpdateBinning(~,~)
global M Ftot

FuncInputPixels();
FuncUpdateFitParam();

end