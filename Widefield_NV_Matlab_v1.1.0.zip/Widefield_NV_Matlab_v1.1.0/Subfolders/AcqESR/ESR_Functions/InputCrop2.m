function InputCrop2(hobject,eventdata)

UpdateXYValues()
CropOrUpdateImage()

end