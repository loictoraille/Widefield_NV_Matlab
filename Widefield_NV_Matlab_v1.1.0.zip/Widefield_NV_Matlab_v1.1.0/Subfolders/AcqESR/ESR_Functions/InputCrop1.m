function InputCrop1(hobject,eventdata)

UpdateWHValues()
CropOrUpdateImage()

end