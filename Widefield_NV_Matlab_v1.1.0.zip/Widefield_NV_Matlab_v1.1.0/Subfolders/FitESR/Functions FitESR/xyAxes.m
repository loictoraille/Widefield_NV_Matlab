function [x_axis, y_axis] = xyAxes(w,h) 
    x_axis = 1:w;
    y_axis = 1:h;
end
