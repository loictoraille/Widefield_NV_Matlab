function UpdateFitParam(~,~)
global M Ftot

FuncUpdateFitParam();

end